function msg()
{
    alert("Hello UMT Student");
}