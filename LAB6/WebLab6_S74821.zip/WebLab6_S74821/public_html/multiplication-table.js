function generateTable() {
    let rows = document.getElementById("rows").value;
    let columns = document.getElementById("columns").value;

    if (rows < 1 || columns < 1) {
        alert("Please enter valid numbers!");
        return;
    }

    let tableHTML = "<table><tr><th>*</th>";

    // Header row
    for (let c = 1; c <= columns; c++) {
        tableHTML += "<th>" + c + "</th>";
    }
    tableHTML += "</tr>";

    // Table rows
    for (let r = 1; r <= rows; r++) {
        tableHTML += "<tr><th>" + r + "</th>";
        for (let c = 1; c <= columns; c++) {
            tableHTML += "<td>" + (r * c) + "</td>";
        }
        tableHTML += "</tr>";
    }

    tableHTML += "</table>";

    document.getElementById("tableContainer").innerHTML = tableHTML;
}
