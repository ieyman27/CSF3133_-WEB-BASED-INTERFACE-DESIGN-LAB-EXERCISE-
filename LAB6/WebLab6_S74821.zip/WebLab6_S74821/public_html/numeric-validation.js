function validateNumericInput() {
    let age = document.getElementById("age").value.trim();

    if (age === "") {
        alert("Please enter your age.");
        return false;
    }

    if (isNaN(age)) {
        alert("Please enter numbers only!");
        return false;
    }

    if (age < 0) {
        alert("Age cannot be negative!");
        return false;
    }

    alert("Valid input! Your age is: " + age);
    return false; // Change to true if you want actual form submission
}
