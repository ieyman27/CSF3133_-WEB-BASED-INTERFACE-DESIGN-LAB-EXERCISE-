let questions = [
    {
        question: "What does HTML stand for?",
        options: ["Hyper Text Markup Language", "Home Tool Markup Language", "Hyperlinks Marking List"],
        answer: 0
    },
    {
        question: "Which programming language runs in a web browser?",
        options: ["Java", "Python", "JavaScript"],
        answer: 2
    },
    {
        question: "What does CSS control?",
        options: ["Structure", "Style", "Database"],
        answer: 1
    }
];

let currentIndex = 0;
let score = 0;
let timeLeft = 10;
let timer;

function shuffleQuestions() {
    questions.sort(() => Math.random() - 0.5);
}

function startTimer() {
    timeLeft = 10;
    document.getElementById("time").textContent = timeLeft;

    timer = setInterval(() => {
        timeLeft--;
        document.getElementById("time").textContent = timeLeft;

        if (timeLeft <= 0) {
            clearInterval(timer);
            checkAnswer(-1); 
        }
    }, 1000);
}

function displayQuestion() {
    let q = questions[currentIndex];
    document.getElementById("question-text").textContent = q.question;

    let optionBox = document.getElementById("options");
    optionBox.innerHTML = "";

    q.options.forEach((opt, index) => {
        optionBox.innerHTML += `
            <button onclick="checkAnswer(${index})">${opt}</button>
        `;
    });
}

function checkAnswer(selected) {
    clearInterval(timer);

    let feedback = document.getElementById("feedback");

    // Reset animation
    feedback.style.opacity = "0";
    feedback.style.animation = "none";

    // Trigger animation and feedback message
    setTimeout(() => {
        if (selected === questions[currentIndex].answer) {
            score++; // FIXED: Score updates again
            feedback.textContent = "Correct!";
            feedback.style.color = "green";
        } else {
            feedback.textContent = "Incorrect!";
            feedback.style.color = "red";
        }

        // Fade-in animation
        feedback.style.animation = "fadeIn 0.6s ease-out forwards";
    }, 50);

    document.getElementById("score").textContent = score;
}

function nextQuestion() {
    currentIndex++;

    if (currentIndex >= questions.length) {
        document.getElementById("question-text").textContent = "Quiz Completed!";
        document.getElementById("options").innerHTML = "";
        document.getElementById("timer").style.display = "none";
        document.getElementById("next-btn").style.display = "none";
        return;
    }

    document.getElementById("feedback").textContent = "";
    displayQuestion();
    startTimer();
}

function startQuiz() {
    shuffleQuestions();
    displayQuestion();
    startTimer();
}

function nextQuestion() {
    currentIndex++;

    if (currentIndex >= questions.length) {
        showSummary();
        return;
    }

    document.getElementById("feedback").textContent = "";
    displayQuestion();
    startTimer();
}
function showSummary() {
    // Hide quiz section
    document.getElementById("quiz-section").style.display = "none";
    document.getElementById("feedback").style.display = "none";

    // Show summary section
    document.getElementById("summary").style.display = "block";

    let total = questions.length;
    let percentage = Math.round((score / total) * 100);

    document.getElementById("final-score").textContent =
        "Your Score: " + score + " / " + total;

    document.getElementById("final-percentage").textContent =
        "Percentage: " + percentage + "%";

    let message = "";
    if (percentage === 100) message = "Excellent! 🎉 Perfect score!";
    else if (percentage >= 70) message = "Great job! Keep it up!";
    else if (percentage >= 40) message = "Not bad! Try again!";
    else message = "Don't give up! Practice makes perfect! 💪";

    document.getElementById("final-message").textContent = message;
}

function restartQuiz() {
    // Reset variables
    currentIndex = 0;
    score = 0;

    // Reset display
    document.getElementById("score").textContent = score;
    document.getElementById("summary").style.display = "none";
    document.getElementById("quiz-section").style.display = "block";
    document.getElementById("feedback").style.display = "block";
    document.getElementById("feedback").textContent = "";

    // Restart quiz
    startQuiz();
}

startQuiz();
