// Basic client-side validation for demo purposes
function validateForm() {
    // clear previous errors
    document.getElementById('fnameError').textContent = '';
    document.getElementById('emailError').textContent = '';

    const fname = document.getElementById('fname').value.trim();
    const email = document.getElementById('email').value.trim();

    let valid = true;

    // Validate first name
    if (fname === '') {
        document.getElementById('fnameError').textContent = 'Please enter your first name.';
        valid = false;
    } else if (fname.length < 2) {
        document.getElementById('fnameError').textContent = 'Name must be at least 2 characters.';
        valid = false;
    }

    // Validate email (simple regex)
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
        document.getElementById('emailError').textContent = 'Please enter your email address.';
        valid = false;
    } else if (!emailPattern.test(email)) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address.';
        valid = false;
    }

    // If not valid, prevent form submission
    if (!valid) {
        return false;
    }

    // For demo: show success and prevent actual submit
    alert('Form submitted successfully!\nName: ' + fname + '\nEmail: ' + email);
    return false; // change to true when you want the form to actually submit
}
